Fancy-Sky

Mod for "Vintage Story"

 The moon and sun are round, and the night sky with stars is also changed.
 At this stage, the files with the changed starry sky are not automatically replaced by the game itself!
 So if you want to see the starry sky from the mod, copy the folder with these files manually to the directory
 
 "\Vintagestory\assets\game\textures\environment"
 
 I also advise you to create a copy of the folder
 
 "environment"

 before you replace the sky files. I hope you enjoy it :)
 

https://github.com/kaev-i/Fancy-Sky/

https://www.twitch.tv/kaev_i